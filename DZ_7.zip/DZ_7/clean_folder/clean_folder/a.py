import sys

def bb1():
    print(" bb1")
    for arg in sys.argv:
        print(arg)
    return True

def bb2():
    print(" bb2")

def bb3():
    print(" bb3")


def main() -> None:

    print("+++++++++++++++++++++++++++++++")
    bb1()
    bb2()
    bb3()
    print("-------------------------------")

    i = 0
    for arg in sys.argv:
        if i == 0:
            geral_dir = 'F:/Razbor/'    #   Заглушка для ввода имени папки для сортировки вручную
            i += 1
        elif i== 1:
            geral_dir = arg             #   Получаем имя папки через аргументы при вызове файла
            i += 1
        else:
            a = 0  
    
    print(geral_dir)
    print("===============================")

__name__ = "__name__"
if __name__ == "__name__":
    main()