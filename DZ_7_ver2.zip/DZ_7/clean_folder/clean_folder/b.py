import sys

def bb1():
    print(" bb1")
    for arg in sys.argv:
        print(arg)
    return True

def bb2():
    print(" bb2")

def bb3():
    print(" bb3")
