from setuptools import setup, find_packages


setup(
	name = "clean_folder",
	version = "1.0",
	author = " Sa ",
	entry_points = {
		'console_scripts': ['clean=clean_folder.a:main'],
		},
	packages = find_packages(),
	discription = "Clean folder script",
)