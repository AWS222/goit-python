import re, os


def Begin():    #  Печать подсказок синтаксиса вводимых команд
    print("===========================  Begin  ==============================\n")
    print("Commandes for input:")
    print("<hello>, <help>\t\t\t - For help")
    print("<add new_name new_tel>\t\t - For add new contact")
    print("<change name new_tel>\t\t - For change number telephone")
    print("<phone name>\t\t\t - For demonstration number telephone")
    print("<good bye>, <exit>, <close>, <.>\t - For exit")
    print(" Format for Telephone < 000-0000000 >\n")

def input_error(func):
    def wrapper(string: str) -> str:
        try:
            return func(string)
        except ValueError as e:
            print(e)
        except KeyError as e:
            print(e)
        except IndexError as e:
            print(e)
    return wrapper

@input_error        #  Добавление нового контакта
def fun_add(string: str) -> str:
    str_tempo = string.split(' ')
    if len(str_tempo) == 3:
        if str_tempo[1].__hash__:
            if re.fullmatch(r'\d{3}-\d{7}', str_tempo[2]):
                Data_phone.update({str_tempo[1]:str_tempo[2]})
                return " Add Ok"
            else:
                return " Telephone uncorect. Format for Telephone < 000-0000000 >"
        else:
            return " Name uncorect"
    else:
        return " Comand uncorect"

@input_error
def fun_phone(string: str) -> str:
    str_tempo = string.split(' ')
    string_out = ''
    if len(str_tempo) == 2:
        if Data_phone.__contains__(str_tempo[1]):
            string_out = f' Name: {str_tempo[1]} tel: {Data_phone[str_tempo[1]]}'
        else:
            string_out = f" Name < {str_tempo[1]} > not found"
    else:
        string_out = " Comand uncorect"

    return string_out

@input_error   
def fun_change(string: str) -> str:
    str_tempo = string.split(' ')
    if len(str_tempo) == 3:
        if Data_phone.__contains__(str_tempo[1]):
            if re.fullmatch(r'\d{3}-\d{7}', str_tempo[2]):
                Data_phone[str_tempo[1]] = str_tempo[2]
                return " Change Ok"
            else:
                return " Telephone uncorect. Format for Telephone < 000-0000000 >"
        else:
            return f" Name < {str_tempo[1]} > not found"
    else:
        return " Comand uncorect"

def fun_hello(string: str) -> str:
    if string.lower() == "hello":
        Begin()
        return "How can I help you?"
    else:
        return " Comand uncorect"
    
def fun_show(string: str) -> str:
    if string.lower() == "show all":
        print(f'\n\tName\tTelephone\n')
        for name, tel in Data_phone.items():
            print(f"\t{name}\t{tel}") 
        return " Show all Ok"
    else:
        return " Comand uncorect"

def write_Data_phone():
    #  Переходим туда где находится наш скрипт для записи данных
    os.chdir(os.path.dirname(os.path.realpath(__file__)))
    with open(('tel.txt'), 'w') as f:
        for k in Data_phone:
            f.writelines(f"{k}:{Data_phone[k]}:\n") 

def read_Data_phone():
    #  Переходим туда где находится наш файл с контактами
    os.chdir(os.path.dirname(os.path.realpath(__file__)))
    with open(('tel.txt'), 'r') as f:
        for line in f:
            st = line.split(":")
            Data_phone.update({st[0]:st[1]})
            #print(k)
            #f.writelines(f"{k}:{Data_phone[k]}") 


Data_phone = {}
"""
Data_phone = {          # Книга контактов: имя и номер телефона
    "Aa": '095-1111101',    #  Начальные данные
    "Ab": '095-1111102',    #  Сделать в отдельном файле
    "Ba": '095-1111103',
    "Bb": '095-1111104',
    "Ca": '095-1111105',
    "Cb": '095-1111106',
    "Cc": '095-1111107',
    "Cd": '095-1111108',
    "Da": '095-1111109',
    "Db": '095-1111110'}
"""

Data_com = {    #  Список команд, которые обрабатываются в консоли
    "hello": fun_hello,
    "help": fun_hello,
    "add": fun_add, 
    "change": fun_change, 
    "phone": fun_phone,
    "show": fun_show}

Data_exit = {"good bye", "close", "exit", "."}  #  Список уоманд для выхода 
Data_correct = {i for i in Data_com}    #  Set для проверки входных данных

#  Считываем телефонную книгу из ф. < tel.txt > в dict < Data_phone >
read_Data_phone()  