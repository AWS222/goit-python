import mod_9    #  Все функции в этом модуле


def main()->None:

    mod_9.Begin()
    str_input = 'ok'

    while not(str_input in mod_9.Data_exit):

        str_input = input(' Input command: ')   #  Данные от user
        n = str_input.split(' ')    #  Выделение 1-го слова из команды
        name_com = n[0].lower()   #  Имя команды (не зависимо от регистра)

        if str_input in mod_9.Data_exit:       #  Проверка на команду на выход
            print("Good bye!")
            break 
        elif name_com in mod_9.Data_correct:      #  Проверка на нужную команду   
            print(mod_9.Data_com.get(name_com)(str_input))   #  Вызов соотв. команды
        else:                               #  Некорректный ввод
            print(" Comand uncorect") 
    
    mod_9.write_Data_phone()
    print("\n============================  End  ==============================")


if __name__ == '__main__':
    main()